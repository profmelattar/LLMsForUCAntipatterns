"""Score the stage 2 judge replies against the stage 2 construction key.

Run from the package root:   python scoring/score_stage2.py

Each of the 24 models carries three planted fragments; one model (S2-CL-03) also
has an accidental AP22 problem found during verification, so there are 25
problems. A problem counts as caught only when the judge gives a PROBLEM verdict
for that antipattern and its Constructs line names every construct listed in
problem_constructs (case-insensitive). Any other PROBLEM verdict is a false alarm.
"""
import collections, csv, os, sys
sys.path.insert(0, os.path.dirname(__file__))
from parse_reply import parse_reply, APS

ROOT = os.path.join(os.path.dirname(__file__), '..', 'stage2')
JUDGES = ['Claude', 'ChatGPT', 'Gemini']
units = list(csv.DictReader(open(os.path.join(ROOT, 'stage2_construction_key.csv'), encoding='utf-8')))
NIDS = sorted({u['neutral_id'] for u in units})
problems = [u for u in units if u['type'] == 'problem']
near = [u for u in units if u['type'] == 'near miss']
print(f'{len(NIDS)} models, {len(units)} labelled fragments, {len(problems)} problems, {len(near)} planted near misses\n')

caught = collections.defaultdict(int)      # (judge, nid, ap) -> runs caught
fa = collections.defaultdict(set)          # (judge, nid, ap) -> runs with a false alarm
per_run = {j: {r: [0, 0] for r in (1, 2, 3)} for j in JUDGES}   # caught, false alarms
near_reported = collections.Counter()
for j in JUDGES:
    for nid in NIDS:
        mine = [u for u in problems if u['neutral_id'] == nid]
        for r in (1, 2, 3):
            ok, fs, bad = parse_reply(open(os.path.join(ROOT, '6_judge_replies', j, f'{nid}_r{r}.txt'), encoding='utf-8').read())
            assert ok and not bad, (j, nid, r)
            prob = [f for f in fs if f['Verdict'] == 'PROBLEM']
            used = set()
            for u in mine:
                names = [n.strip().lower() for n in u['problem_constructs'].split(';')]
                hit = [i for i, f in enumerate(prob) if f['Antipattern'] == u['antipattern'] and all(n in f['Constructs'].lower() for n in names)]
                if hit:
                    caught[(j, nid, u['antipattern'])] += 1; per_run[j][r][0] += 1; used.update(hit)
            for i, f in enumerate(prob):
                if i not in used:
                    fa[(j, nid, f['Antipattern'])].add(r); per_run[j][r][1] += 1
            for u in near:
                if u['neutral_id'] == nid and any(f['Antipattern'] == u['antipattern'] for f in fs):
                    near_reported[(j, u['antipattern'])] += 1

print('Per run: problems caught (of 25) and false alarms')
for j in JUDGES:
    print(f'  {j:8} caught {[per_run[j][r][0] for r in (1, 2, 3)]}  false alarms {[per_run[j][r][1] for r in (1, 2, 3)]}')

print('\nMajority of three runs')
for j in JUDGES:
    c = sum(caught[(j, u["neutral_id"], u["antipattern"])] >= 2 for u in problems)
    missed = [u['model_id'] + ' ' + u['antipattern'] for u in problems if caught[(j, u['neutral_id'], u['antipattern'])] < 2]
    f = sorted(k[1] + ' ' + k[2] for k, v in fa.items() if k[0] == j and len(v) >= 2)
    mid = {u['neutral_id']: u['model_id'] for u in units}
    f = [mid[x.split()[0]] + ' ' + x.split()[1] for x in f]
    print(f'  {j:8} caught {c} of {len(problems)}; missed {missed or "none"}; false alarms {len(f)} {f}')

print('\nRuns in which a finding for the same antipattern was reported on a model with a planted near miss (judge, antipattern)')
print('  ', dict(near_reported) or 'none')


# Agreement and confidence intervals, computed as in stage 1: a binary PROBLEM verdict on
# every model-antipattern pair (24 models x 6 antipatterns). For a pair with a problem, the
# verdict counts only when the constructs rule is met; any other PROBLEM verdict counts as one.
replies = {(j, nid, r): parse_reply(open(os.path.join(ROOT, '6_judge_replies', j, f'{nid}_r{r}.txt'), encoding='utf-8').read())[1]
           for j in JUDGES for nid in NIDS for r in (1, 2, 3)}
pconstructs = {(u['neutral_id'], u['antipattern']): u['problem_constructs'] for u in problems}


def verdict(j, nid, r, a):
    prob = [f for f in replies[(j, nid, r)] if f['Antipattern'] == a and f['Verdict'] == 'PROBLEM']
    if not prob:
        return False
    if (nid, a) in pconstructs:
        names = [n.strip().lower() for n in pconstructs[(nid, a)].split(';')]
        return any(all(n in f['Constructs'].lower() for n in names) for f in prob)
    return True


def majority(j, nid, a):
    return sum(verdict(j, nid, r, a) for r in (1, 2, 3)) >= 2


def fleiss(ratings):
    N, n = len(ratings), len(ratings[0])
    P = [(sum(x) * (sum(x) - 1) + (n - sum(x)) * (n - sum(x) - 1)) / (n * (n - 1)) for x in ratings]
    p1 = sum(map(sum, ratings)) / (N * n); pe = p1 ** 2 + (1 - p1) ** 2
    return (sum(P) / N - pe) / (1 - pe) if pe < 1 else float('nan')


def wilson(k, n, z=1.96):
    p = k / n; d = 1 + z * z / n; c = (p + z * z / (2 * n)) / d
    h = z * (p * (1 - p) / n + z * z / (4 * n * n)) ** 0.5 / d
    return f'{k}/{n} = {100 * p:.1f}% (95% CI {100 * (c - h):.1f}-{100 * (c + h):.1f}%)'


pairs = [(nid, a) for nid in NIDS for a in APS]
print(f'\nAgreement over all {len(NIDS)} x {len(APS)} model-antipattern pairs (Fleiss kappa)')
for j in JUDGES:
    print(f'  {j:8} across its three runs: {fleiss([[verdict(j, nid, r, a) for r in (1, 2, 3)] for nid, a in pairs]):.3f}')
print(f'  Across the three judges (majority verdicts): {fleiss([[majority(j, nid, a) for j in JUDGES] for nid, a in pairs]):.3f}')

print('\nThree-judge panel (majority of the judges\' majority verdicts)')
panel_caught = sum(sum(caught[(j, u['neutral_id'], u['antipattern'])] >= 2 for j in JUDGES) >= 2 for u in problems)
panel_fa = sum(sum(len(fa[(j, k[0], k[1])]) >= 2 for j in JUDGES) >= 2 for k in {(k[1], k[2]) for k in fa})
print(f'  caught {panel_caught} of {len(problems)}; false alarms {panel_fa}')

print('\nProblems caught by majority of three runs, with Wilson 95% confidence intervals')
for j in JUDGES:
    print(f'  {j:8} {wilson(sum(caught[(j, u["neutral_id"], u["antipattern"])] >= 2 for u in problems), len(problems))}')
