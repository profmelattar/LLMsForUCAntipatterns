"""Parse a judge reply written in the fixed format of evaluation prompt v1.0."""
import re

APS = ['AP1', 'AP2', 'AP5', 'AP6', 'AP17', 'AP22']
FIELDS = ['Antipattern', 'Constructs', 'Trigger evidence', 'Verdict', 'Criterion', 'Reason', 'Improvement']


def parse_reply(text):
    """Return (complete, findings, malformed). Each finding is a dict of the FIELDS."""
    t = text.strip()
    complete = t.startswith('=== FINDINGS ===') and t.endswith('=== END ===')
    body = t.replace('=== FINDINGS ===', '').replace('=== END ===', '').strip()
    if body == 'NO FINDINGS':
        return complete, [], []
    findings, malformed = [], []
    for block in re.split(r'(?m)^FINDING\s+\d+\s*$', body)[1:]:
        f = {}
        for k in FIELDS:
            m = re.search(r'(?ms)^%s:\s*(.*?)(?=^(?:%s):|\Z)' % (re.escape(k), '|'.join(map(re.escape, FIELDS))), block)
            f[k] = m.group(1).strip() if m else None
        if any(v is None for v in f.values()) or f['Antipattern'] not in APS or f['Verdict'] not in ('ACCEPTABLE', 'PROBLEM'):
            malformed.append(f)
        findings.append(f)
    if not findings:
        complete = False
    return complete, findings, malformed
