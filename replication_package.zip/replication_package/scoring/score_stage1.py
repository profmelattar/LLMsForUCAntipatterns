"""Score the stage 1 judge replies against the stage 1 construction key.

Run from the package root:   python scoring/score_stage1.py

Scored models: each model is scored only against the antipattern it was built for
(230 models; the 10 clean models are not scored). A problem counts as caught only
when the judge gives a PROBLEM verdict for that antipattern and its Constructs
line names every construct listed in problem_constructs. A PROBLEM verdict on an
acceptable or near-miss model's own antipattern is a false alarm.
"""
import csv, itertools, os, sys
sys.path.insert(0, os.path.dirname(__file__))
from parse_reply import parse_reply, APS

ROOT = os.path.join(os.path.dirname(__file__), '..', 'stage1')
JUDGES = ['Claude', 'ChatGPT', 'Gemini']
KEY = {r['neutral_id']: r for r in csv.DictReader(open(os.path.join(ROOT, 'stage1_construction_key.csv'), encoding='utf-8'))}
MIDS = sorted(KEY)

# replies[judge][mid][rep] = list of findings
replies = {j: {m: {} for m in MIDS} for j in JUDGES}
for j in JUDGES:
    for m in MIDS:
        for r in (1, 2, 3):
            ok, fs, bad = parse_reply(open(os.path.join(ROOT, '5_judge_replies', j, f'{m}_r{r}.txt'), encoding='utf-8').read())
            assert ok and not bad, (j, m, r)
            replies[j][m][r] = fs


def is_problem_cell(m, a):
    return KEY[m]['antipattern'] == a and KEY[m]['model_type'] == 'problem'


def verdict(j, m, r, a):
    """Scored PROBLEM verdict of judge j, run r, on model m for antipattern a."""
    prob = [f for f in replies[j][m][r] if f['Antipattern'] == a and f['Verdict'] == 'PROBLEM']
    if not prob:
        return False
    if is_problem_cell(m, a):
        names = [n.strip() for n in KEY[m]['problem_constructs'].split(';')]
        text = ' '.join(f['Constructs'] for f in prob)
        return all(n in text for n in names)
    return True


def majority(j, m, a):
    return sum(verdict(j, m, r, a) for r in (1, 2, 3)) >= 2


own = [(m, KEY[m]['antipattern']) for m in MIDS if KEY[m]['model_type'] != 'clean']
problems = [(m, a) for m, a in own if KEY[m]['model_type'] == 'problem']
non_problems = [(m, a) for m, a in own if KEY[m]['model_type'] != 'problem']
near_misses = [(m, a) for m, a in own if KEY[m]['model_type'] == 'near miss']
print(f'Scored models: {len(own)} ({len(problems)} problems, {len(non_problems)} non-problems)\n')

print('Errors per run (unsafe = problem not caught; safe = false alarm)')
for j in JUDGES:
    unsafe = [sum(not verdict(j, m, r, a) for m, a in problems) for r in (1, 2, 3)]
    safe = [sum(verdict(j, m, r, a) for m, a in non_problems) for r in (1, 2, 3)]
    by_ap = {a: [sum(not verdict(j, m, r, a2) for m, a2 in problems if a2 == a) for r in (1, 2, 3)] for a in APS}
    fa_ap = {a: [sum(verdict(j, m, r, a2) for m, a2 in non_problems if a2 == a) for r in (1, 2, 3)] for a in APS}
    print(f'  {j:8} unsafe {unsafe}  safe {safe}')
    print(f'           unsafe by antipattern { {a: v for a, v in by_ap.items() if any(v)} }')
    print(f'           safe by antipattern   { {a: v for a, v in fa_ap.items() if any(v)} }')

print('\nNear misses with any finding on their own antipattern (any run):')
for j in JUDGES:
    n = sum(any(f['Antipattern'] == a for r in (1, 2, 3) for f in replies[j][m][r]) for m, a in near_misses)
    print(f'  {j:8} {n} of {len(near_misses)}')

print('\nMajority of three runs, and three-judge panel (majority of the judges\' majorities)')
panel = lambda m, a: sum(majority(j, m, a) for j in JUDGES) >= 2
for name, fn in [(j, (lambda m, a, j=j: majority(j, m, a))) for j in JUDGES] + [('Panel', panel)]:
    print(f'  {name:8} unsafe {sum(not fn(m, a) for m, a in problems)}  safe {sum(fn(m, a) for m, a in non_problems)}')


def fleiss(ratings):
    N, n = len(ratings), len(ratings[0])
    P = [(sum(x) * (sum(x) - 1) + (n - sum(x)) * (n - sum(x) - 1)) / (n * (n - 1)) for x in ratings]
    p1 = sum(map(sum, ratings)) / (N * n); pe = p1 ** 2 + (1 - p1) ** 2
    return (sum(P) / N - pe) / (1 - pe) if pe < 1 else float('nan')


pairs = [(m, a) for m in MIDS for a in APS]  # every model against every antipattern in the prompt
print('\nAgreement over all 240 x 6 model-antipattern pairs (Fleiss kappa)')
for j in JUDGES:
    print(f'  {j:8} across its three runs: {fleiss([[verdict(j, m, r, a) for r in (1, 2, 3)] for m, a in pairs]):.3f}')
print(f'  Across the three judges (majority verdicts): {fleiss([[majority(j, m, a) for j in JUDGES] for m, a in pairs]):.3f}')


def wilson(k, n, z=1.96):
    p = k / n; d = 1 + z * z / n; c = (p + z * z / (2 * n)) / d
    h = z * (p * (1 - p) / n + z * z / (4 * n * n)) ** 0.5 / d
    return f'{k}/{n} = {100 * p:.1f}% (95% CI {100 * (c - h):.1f}-{100 * (c + h):.1f}%)'


print('\nProblems detected by majority of three runs, with Wilson 95% confidence intervals')
for j in JUDGES:
    print(f'  {j:8} {wilson(sum(majority(j, m, a) for m, a in problems), len(problems))}')
