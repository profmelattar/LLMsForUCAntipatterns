"""Full evaluation run for the judge ChatGPT (gpt-6-astra), through the OpenAI Batch API.

Run from the folder that contains 'scripts', 'prompts' and 'models':

    py scripts/chatgpt_batch_stage2.py submit --dry-run   build the requests, send nothing
    py scripts/chatgpt_batch_stage2.py submit             send all 72 requests as one batch
    py scripts/chatgpt_batch_stage2.py status             show how far the batch is
    py scripts/chatgpt_batch_stage2.py fetch              download the replies when it has ended
    py scripts/chatgpt_batch_stage2.py submit --missing   send again only what is missing or incomplete
    add  --reps 1  (or --reps 2,3 and so on) to send only some repetitions

OpenAI limits how many input tokens may wait in batches at one time (1,350,000
for this account), and all 72 stage 2 requests are about 340,000. So send the
repetitions in parts: --reps 1,2 first (about 1,100,000), and --reps 3 once
the first part has ended. 'status' and 'fetch' handle every batch sent.

Needs: the 'openai' library and the environment variable OPENAI_API_KEY.
24 models x 3 repetitions = 72 requests to /v1/responses. Each request is one
separate call: the fixed prompt with one model inserted. No instructions and no
temperature or reasoning setting, so the model's defaults apply.
"""
import argparse, csv, datetime, glob, json, os, sys

MODEL = "gpt-6-astra"
MAX_TOKENS = 25000
REPETITIONS = 3
PROMPT_FILE = "prompts/evaluation_prompt_v1.0.txt"
MODELS_DIR = "models"
OUT_DIR = "outputs/ChatGPT/stage2"
LOG_FILE = OUT_DIR + "/run_log.csv"
BATCH_FILE = OUT_DIR + "/batch_ids.txt"
FETCHED_FILE = OUT_DIR + "/batch_ids_fetched.txt"
REQUEST_FILE = OUT_DIR + "/batch_requests.jsonl"

def complete(text):
    t = text.strip()
    return t.startswith("=== FINDINGS ===") and t.endswith("=== END ===")

def all_ids():
    ids = sorted(os.path.basename(p)[:-4] for p in glob.glob(MODELS_DIR + "/N*.txt"))
    if len(ids) != 24:
        sys.exit(f"Expected 24 model files in '{MODELS_DIR}', found {len(ids)}.")
    return [f"{m}_r{r}" for r in range(1, REPETITIONS + 1) for m in ids]

def missing_ids():
    out = []
    for cid in all_ids():
        p = f"{OUT_DIR}/{cid}.txt"
        if not os.path.exists(p) or not complete(open(p, encoding="utf-8").read()):
            out.append(cid)
    return out

def client():
    import openai
    if not os.environ.get("OPENAI_API_KEY"):
        sys.exit("Set the environment variable OPENAI_API_KEY first.")
    return openai.OpenAI()

def submit(args):
    prompt = open(PROMPT_FILE, encoding="utf-8").read()
    if prompt.count("{MODEL}") != 1:
        sys.exit("The prompt file must contain {MODEL} exactly once.")
    ids = missing_ids() if args.missing else all_ids()
    if args.reps:
        keep = {f"_r{r.strip()}" for r in args.reps.split(",")}
        ids = [c for c in ids if c[c.index("_r"):] in keep]
    if not ids:
        print("Nothing to send: every reply is already saved and complete."); return
    lines, chars = [], 0
    for cid in ids:
        mid = cid.split("_")[0]
        model_text = open(f"{MODELS_DIR}/{mid}.txt", encoding="utf-8").read().strip()
        message = prompt.replace("{MODEL}", model_text)
        chars += len(message)
        lines.append(json.dumps({"custom_id": cid, "method": "POST", "url": "/v1/responses",
                                 "body": {"model": MODEL, "input": message, "max_output_tokens": MAX_TOKENS}},
                                ensure_ascii=False))
    print(f"{len(lines)} requests built ({chars} characters in all, about {chars // 4:,} tokens), "
          f"first {ids[0]}, last {ids[-1]}.")
    os.makedirs(OUT_DIR, exist_ok=True)
    with open(REQUEST_FILE, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    if args.dry_run:
        print(f"Dry run: request file written to {REQUEST_FILE}, nothing sent."); return
    cl = client()
    up = cl.files.create(file=open(REQUEST_FILE, "rb"), purpose="batch")
    b = cl.batches.create(input_file_id=up.id, endpoint="/v1/responses", completion_window="24h")
    with open(BATCH_FILE, "a") as f:
        f.write(b.id + "\n")
    print(f"Batch submitted: {b.id}  status: {b.status}")
    print("Check later with:  py scripts/chatgpt_batch_stage2.py status")

def all_batches():
    if not os.path.exists(BATCH_FILE):
        sys.exit("No batch has been submitted yet.")
    return open(BATCH_FILE).read().split()

def fetched_batches():
    return open(FETCHED_FILE).read().split() if os.path.exists(FETCHED_FILE) else []

def status(args):
    cl = client()
    done = fetched_batches()
    for bid in all_batches():
        b = cl.batches.retrieve(bid)
        c = b.request_counts
        counts = f"completed {c.completed}, failed {c.failed}, total {c.total}" if c else ""
        note = " (already fetched)" if bid in done else ""
        print(f"Batch {b.id}: {b.status}. {counts}{note}")
        if b.status == "failed" and b.errors:
            print("   failed, nothing was charged:", "; ".join(e.message for e in b.errors.data))
    print("When a batch is 'completed', download with:  py scripts/chatgpt_batch_stage2.py fetch")

def reply_text(body):
    parts = []
    for item in body.get("output") or []:
        if item.get("type") == "message":
            for c in item.get("content") or []:
                if c.get("type") == "output_text":
                    parts.append(c.get("text", ""))
    return "".join(parts)

def fetch(args):
    cl = client()
    done = fetched_batches()
    any_new = False
    for bid in all_batches():
        if bid in done:
            continue
        b = cl.batches.retrieve(bid)
        if b.status == "failed":
            print(f"Batch {bid} failed (nothing to download).")
            open(FETCHED_FILE, "a").write(bid + "\n"); continue
        if b.status not in ("completed", "expired", "cancelled"):
            print(f"Batch {bid} is still '{b.status}'. Try again later."); continue
        fetch_one(cl, b)
        open(FETCHED_FILE, "a").write(bid + "\n")
        any_new = True
    left = missing_ids()
    if left:
        print(f"{len(left)} of 72 replies are still missing or incomplete "
              f"(repetitions: {sorted({c.split('_r')[1] for c in left})}).")
    else:
        print("All 72 replies are saved and complete.")

def fetch_one(cl, b):
    bid = b.id
    os.makedirs(OUT_DIR, exist_ok=True)
    raw = ""
    for fid, name in ((b.output_file_id, "output"), (b.error_file_id, "errors")):
        if fid:
            t = cl.files.content(fid).text
            open(f"{OUT_DIR}/batch_{name}_{bid}.jsonl", "w", encoding="utf-8").write(t)
            raw += t + "\n"
    new = not os.path.exists(LOG_FILE)
    log = open(LOG_FILE, "a", newline="", encoding="utf-8"); w = csv.writer(log)
    if new:
        w.writerow(["custom_id", "neutral_id", "repetition", "batch_id", "fetched_utc", "result_type",
                    "model_returned", "status", "input_tokens", "output_tokens", "reasoning_tokens", "complete", "reply_file"])
    now = datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")
    n_ok = n_bad = tin = tout = 0
    for line in raw.splitlines():
        if not line.strip():
            continue
        rec = json.loads(line)
        cid = rec["custom_id"]; mid, rep = cid.split("_r")
        resp = rec.get("response") or {}
        body = resp.get("body") or {}
        if rec.get("error") or resp.get("status_code") != 200:
            err = (rec.get("error") or body.get("error") or {})
            w.writerow([cid, mid, rep, bid, now, "error:" + str(err.get("code", resp.get("status_code"))),
                        "", "", "", "", "", "NO", ""]); n_bad += 1
            continue
        text = reply_text(body)
        path = f"{OUT_DIR}/{cid}.txt"
        open(path, "w", encoding="utf-8").write(text)
        ok = complete(text); n_ok += ok; n_bad += (not ok)
        st = body.get("status", "")
        if st == "incomplete" and body.get("incomplete_details"):
            st += ":" + str(body["incomplete_details"].get("reason"))
        u = body.get("usage") or {}
        uin, uout = u.get("input_tokens", 0), u.get("output_tokens", 0)
        rtok = (u.get("output_tokens_details") or {}).get("reasoning_tokens", "")
        tin += uin; tout += uout
        w.writerow([cid, mid, rep, bid, now, "succeeded", body.get("model", ""), st,
                    uin, uout, rtok, "yes" if ok else "NO", path])
    log.close()
    print(f"Batch {bid}: saved. Complete replies: {n_ok}. Not usable (error, expired or incomplete): {n_bad}.")
    print(f"Tokens: input {tin}, output {tout}. Approximate batch cost at $5 / $25 per million: "
          f"${tin / 1e6 * 5 + tout / 1e6 * 25:.2f}")

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("submit"); s.add_argument("--dry-run", action="store_true"); s.add_argument("--missing", action="store_true"); s.add_argument("--reps", default=""); s.set_defaults(f=submit)
    sub.add_parser("status").set_defaults(f=status)
    sub.add_parser("fetch").set_defaults(f=fetch)
    a = ap.parse_args(); a.f(a)
