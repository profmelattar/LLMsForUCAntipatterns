"""Full evaluation run for the judge Gemini (gemini-3.1-pro-preview), through the Gemini Batch API.

Run from the folder that contains 'scripts', 'prompts' and 'models':

    py scripts/gemini_batch_stage2.py submit --dry-run   build the requests, send nothing
    py scripts/gemini_batch_stage2.py submit             send all 72 requests as one batch job
    py scripts/gemini_batch_stage2.py status             show how far the job is
    py scripts/gemini_batch_stage2.py fetch              download the replies when it has ended
    py scripts/gemini_batch_stage2.py submit --missing   send again only what is missing or incomplete

Needs: the 'google-genai' library and the environment variable GEMINI_API_KEY.
24 models x 3 repetitions = 72 requests. Each request is one separate call:
the fixed prompt with one model inserted. No system instruction and no
temperature or thinking setting, so the model's defaults apply.
"""
import argparse, csv, datetime, glob, json, os, sys

MODEL = "gemini-3.1-pro-preview"
MAX_TOKENS = 25000
REPETITIONS = 3
PROMPT_FILE = "prompts/evaluation_prompt_v1.0.txt"
MODELS_DIR = "models"
OUT_DIR = "outputs/Gemini/stage2"
LOG_FILE = OUT_DIR + "/run_log.csv"
BATCH_FILE = OUT_DIR + "/batch_ids.txt"
REQUEST_FILE = OUT_DIR + "/batch_requests.jsonl"
ENDED = ("JOB_STATE_SUCCEEDED", "JOB_STATE_FAILED", "JOB_STATE_CANCELLED", "JOB_STATE_EXPIRED")

def complete(text):
    t = text.strip()
    return t.startswith("=== FINDINGS ===") and t.endswith("=== END ===")

def all_ids():
    ids = sorted(os.path.basename(p)[:-4] for p in glob.glob(MODELS_DIR + "/N*.txt"))
    if len(ids) != 24:
        sys.exit(f"Expected 24 model files in '{MODELS_DIR}', found {len(ids)}.")
    return [f"{m}_r{r}" for r in range(1, REPETITIONS + 1) for m in ids]

def missing_ids():
    out = []
    for cid in all_ids():
        p = f"{OUT_DIR}/{cid}.txt"
        if not os.path.exists(p) or not complete(open(p, encoding="utf-8").read()):
            out.append(cid)
    return out

def client():
    from google import genai
    if not os.environ.get("GEMINI_API_KEY"):
        sys.exit("Set the environment variable GEMINI_API_KEY first.")
    return genai.Client(api_key=os.environ["GEMINI_API_KEY"])

def last_batch():
    if not os.path.exists(BATCH_FILE):
        sys.exit("No batch has been submitted yet.")
    return open(BATCH_FILE).read().split()[-1]

def submit(args):
    prompt = open(PROMPT_FILE, encoding="utf-8").read()
    if prompt.count("{MODEL}") != 1:
        sys.exit("The prompt file must contain {MODEL} exactly once.")
    ids = missing_ids() if args.missing else all_ids()
    if not ids:
        print("Nothing to send: every reply is already saved and complete."); return
    lines, chars = [], 0
    for cid in ids:
        mid = cid.split("_")[0]
        model_text = open(f"{MODELS_DIR}/{mid}.txt", encoding="utf-8").read().strip()
        message = prompt.replace("{MODEL}", model_text)
        chars += len(message)
        lines.append(json.dumps({"key": cid,
                                 "request": {"contents": [{"role": "user", "parts": [{"text": message}]}],
                                             "generation_config": {"max_output_tokens": MAX_TOKENS}}},
                                ensure_ascii=False))
    print(f"{len(lines)} requests built ({chars} characters in all), first {ids[0]}, last {ids[-1]}.")
    os.makedirs(OUT_DIR, exist_ok=True)
    with open(REQUEST_FILE, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    if args.dry_run:
        print(f"Dry run: request file written to {REQUEST_FILE}, nothing sent."); return
    from google.genai import types
    cl = client()
    up = cl.files.upload(file=REQUEST_FILE,
                         config=types.UploadFileConfig(display_name="evaluation-requests", mime_type="jsonl"))
    job = cl.batches.create(model=MODEL, src=up.name, config={"display_name": "antipattern-evaluation"})
    with open(BATCH_FILE, "a") as f:
        f.write(job.name + "\n")
    print(f"Batch submitted: {job.name}  status: {job.state.name}")
    print("Check later with:  py scripts/gemini_batch_stage2.py status")

def status(args):
    cl = client()   # keep the client open while it is used
    job = cl.batches.get(name=last_batch())
    print(f"Batch {job.name}: {job.state.name}")
    if job.state.name in ENDED:
        print("It has ended. Download with:  py scripts/gemini_batch_stage2.py fetch")
    if job.state.name == "JOB_STATE_FAILED":
        print("The job failed:", job.error)

def g(d, *names):
    """Read a field that may be written in camelCase or snake_case."""
    for n in names:
        if isinstance(d, dict) and n in d:
            return d[n]
    return None

def fetch(args):
    bid = last_batch()
    cl = client()
    job = cl.batches.get(name=bid)
    if job.state.name not in ENDED:
        sys.exit(f"Batch {bid} is still '{job.state.name}'. Try again later.")
    if not (job.dest and job.dest.file_name):
        sys.exit(f"Batch {bid} ended as {job.state.name} with no result file. {job.error or ''}")
    raw = cl.files.download(file=job.dest.file_name).decode("utf-8")
    os.makedirs(OUT_DIR, exist_ok=True)
    open(f"{OUT_DIR}/batch_output_{bid.split('/')[-1]}.jsonl", "w", encoding="utf-8").write(raw)
    new = not os.path.exists(LOG_FILE)
    log = open(LOG_FILE, "a", newline="", encoding="utf-8"); w = csv.writer(log)
    if new:
        w.writerow(["custom_id", "neutral_id", "repetition", "batch_id", "fetched_utc", "result_type",
                    "model_returned", "finish_reason", "input_tokens", "output_tokens", "reasoning_tokens", "complete", "reply_file"])
    now = datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")
    n_ok = n_bad = tin = tout = 0
    for line in raw.splitlines():
        if not line.strip():
            continue
        rec = json.loads(line)
        cid = rec.get("key"); mid, rep = cid.split("_r")
        resp = rec.get("response")
        cands = g(resp, "candidates") or []
        if not resp or not cands:
            err = rec.get("error") or rec.get("status") or g(resp, "promptFeedback", "prompt_feedback") or "no response"
            w.writerow([cid, mid, rep, bid, now, "error:" + json.dumps(err)[:80], "", "", "", "", "", "NO", ""]); n_bad += 1
            continue
        cand = cands[0]
        parts = g(g(cand, "content") or {}, "parts") or []
        text = "".join(p.get("text", "") for p in parts if not p.get("thought"))
        path = f"{OUT_DIR}/{cid}.txt"
        open(path, "w", encoding="utf-8").write(text)
        ok = complete(text); n_ok += ok; n_bad += (not ok)
        um = g(resp, "usageMetadata", "usage_metadata") or {}
        uin = g(um, "promptTokenCount", "prompt_token_count") or 0
        rtok = g(um, "thoughtsTokenCount", "thoughts_token_count") or 0
        uout = (g(um, "candidatesTokenCount", "candidates_token_count") or 0) + rtok   # thinking is billed as output
        tin += uin; tout += uout
        w.writerow([cid, mid, rep, bid, now, "succeeded", g(resp, "modelVersion", "model_version") or "",
                    g(cand, "finishReason", "finish_reason") or "", uin, uout, rtok, "yes" if ok else "NO", path])
    log.close()
    print(f"Saved. Complete replies: {n_ok}. Not usable (error, expired or incomplete): {n_bad}.")
    print(f"Tokens: input {tin}, output {tout}. Approximate batch cost at $1 / $6 per million: "
          f"${tin / 1e6 * 1 + tout / 1e6 * 6:.2f}")
    left = missing_ids()
    if left:
        print(f"{len(left)} replies are still missing or incomplete. Send them again with:\n"
              f"  py scripts/gemini_batch_stage2.py submit --missing")
    else:
        print("All 72 replies are saved and complete.")

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("submit"); s.add_argument("--dry-run", action="store_true"); s.add_argument("--missing", action="store_true"); s.set_defaults(f=submit)
    sub.add_parser("status").set_defaults(f=status)
    sub.add_parser("fetch").set_defaults(f=fetch)
    a = ap.parse_args(); a.f(a)
