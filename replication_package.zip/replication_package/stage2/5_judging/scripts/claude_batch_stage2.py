"""Full evaluation run for the judge Claude, through the Message Batches API.

Run from the folder that contains 'scripts', 'prompts' and 'models':

    py scripts/claude_batch_stage2.py submit --dry-run   build the requests, send nothing
    py scripts/claude_batch_stage2.py submit             send all 72 requests as one batch
    py scripts/claude_batch_stage2.py status             show how far the batch is
    py scripts/claude_batch_stage2.py fetch              download the replies when it has ended
    py scripts/claude_batch_stage2.py submit --missing   send again only what is missing or incomplete

Needs: the 'anthropic' library and the environment variable ANTHROPIC_API_KEY.
24 models x 3 repetitions = 72 requests. Each request is one separate call:
the fixed prompt with one model inserted. No system prompt and no temperature,
thinking or effort setting, so the model's defaults apply.
"""
import argparse, csv, datetime, glob, os, sys

MODEL = "claude-opus-5-5"
MAX_TOKENS = 16000
REPETITIONS = 3
PROMPT_FILE = "prompts/evaluation_prompt_v1.0.txt"
MODELS_DIR = "models"
OUT_DIR = "outputs/Claude/stage2"
LOG_FILE = OUT_DIR + "/run_log.csv"
BATCH_FILE = OUT_DIR + "/batch_ids.txt"

def complete(text):
    t = text.strip()
    return t.startswith("=== FINDINGS ===") and t.endswith("=== END ===")

def all_ids():
    ids = sorted(os.path.basename(p)[:-4] for p in glob.glob(MODELS_DIR + "/N*.txt"))
    if len(ids) != 24:
        sys.exit(f"Expected 24 model files in '{MODELS_DIR}', found {len(ids)}.")
    return [f"{m}_r{r}" for r in range(1, REPETITIONS + 1) for m in ids]

def missing_ids():
    out = []
    for cid in all_ids():
        p = f"{OUT_DIR}/{cid}.txt"
        if not os.path.exists(p) or not complete(open(p, encoding="utf-8").read()):
            out.append(cid)
    return out

def client():
    import anthropic
    if not os.environ.get("ANTHROPIC_API_KEY"):
        sys.exit("Set the environment variable ANTHROPIC_API_KEY first.")
    return anthropic.Anthropic()

def last_batch():
    if not os.path.exists(BATCH_FILE):
        sys.exit("No batch has been submitted yet.")
    return open(BATCH_FILE).read().split()[-1]

def submit(args):
    prompt = open(PROMPT_FILE, encoding="utf-8").read()
    if prompt.count("{MODEL}") != 1:
        sys.exit("The prompt file must contain {MODEL} exactly once.")
    ids = missing_ids() if args.missing else all_ids()
    if not ids:
        print("Nothing to send: every reply is already saved and complete."); return
    requests = []
    for cid in ids:
        mid = cid.split("_")[0]
        model_text = open(f"{MODELS_DIR}/{mid}.txt", encoding="utf-8").read().strip()
        requests.append({"custom_id": cid,
                         "params": {"model": MODEL, "max_tokens": MAX_TOKENS,
                                    "messages": [{"role": "user", "content": prompt.replace("{MODEL}", model_text)}]}})
    chars = sum(len(r["params"]["messages"][0]["content"]) for r in requests)
    print(f"{len(requests)} requests built ({chars} characters in all), "
          f"first {requests[0]['custom_id']}, last {requests[-1]['custom_id']}.")
    if args.dry_run:
        print("Dry run: nothing sent."); return
    os.makedirs(OUT_DIR, exist_ok=True)
    b = client().messages.batches.create(requests=requests)
    with open(BATCH_FILE, "a") as f:
        f.write(b.id + "\n")
    print(f"Batch submitted: {b.id}  status: {b.processing_status}")
    print("Check later with:  py scripts/claude_batch_stage2.py status")

def status(args):
    b = client().messages.batches.retrieve(last_batch())
    c = b.request_counts
    print(f"Batch {b.id}: {b.processing_status}. processing {c.processing}, succeeded {c.succeeded}, "
          f"errored {c.errored}, canceled {c.canceled}, expired {c.expired}")
    if b.processing_status == "ended":
        print("It has ended. Download with:  py scripts/claude_batch_stage2.py fetch")

def fetch(args):
    bid = last_batch()
    cl = client()
    b = cl.messages.batches.retrieve(bid)
    if b.processing_status != "ended":
        sys.exit(f"Batch {bid} is still '{b.processing_status}'. Try again later.")
    os.makedirs(OUT_DIR, exist_ok=True)
    new = not os.path.exists(LOG_FILE)
    log = open(LOG_FILE, "a", newline="", encoding="utf-8"); w = csv.writer(log)
    if new:
        w.writerow(["custom_id", "neutral_id", "repetition", "batch_id", "fetched_utc", "result_type",
                    "model_returned", "stop_reason", "input_tokens", "output_tokens", "complete", "reply_file"])
    now = datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")
    n_ok = n_bad = tin = tout = 0
    for res in cl.messages.batches.results(bid):
        cid = res.custom_id; mid, rep = cid.split("_r")
        if res.result.type != "succeeded":
            w.writerow([cid, mid, rep, bid, now, res.result.type, "", "", "", "", "NO", ""]); n_bad += 1
            continue
        msg = res.result.message
        text = "".join(blk.text for blk in msg.content if blk.type == "text")
        path = f"{OUT_DIR}/{cid}.txt"
        open(path, "w", encoding="utf-8").write(text)
        ok = complete(text)
        n_ok += ok; n_bad += (not ok)
        tin += msg.usage.input_tokens; tout += msg.usage.output_tokens
        w.writerow([cid, mid, rep, bid, now, "succeeded", msg.model, msg.stop_reason,
                    msg.usage.input_tokens, msg.usage.output_tokens, "yes" if ok else "NO", path])
    log.close()
    print(f"Saved. Complete replies: {n_ok}. Not usable (error, expired or incomplete): {n_bad}.")
    print(f"Tokens: input {tin}, output {tout}. Approximate batch cost at $2 / $10 per million: "
          f"${tin / 1e6 * 2 + tout / 1e6 * 10:.2f}")
    left = missing_ids()
    if left:
        print(f"{len(left)} replies are still missing or incomplete. Send them again with:\n"
              f"  py scripts/claude_batch_stage2.py submit --missing")
    else:
        print("All 72 replies are saved and complete.")

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("submit"); s.add_argument("--dry-run", action="store_true"); s.add_argument("--missing", action="store_true"); s.set_defaults(f=submit)
    sub.add_parser("status").set_defaults(f=status)
    sub.add_parser("fetch").set_defaults(f=fetch)
    a = ap.parse_args(); a.f(a)
