"""Stage 2 corpus generation through the APIs: one call per model, default model settings.

Run from inside the Stage 2 folder (the one that contains 'prompts' and 'scripts'):
    py scripts/generate_stage2.py --dry-run                      build the requests, send nothing
    py scripts/generate_stage2.py --only S2-CL-01,S2-CH-01      pilot: generate just these models
    py scripts/generate_stage2.py                                generate every model not yet saved

S2-CL-* models go to Claude, S2-CH-* models go to ChatGPT.
Needs: py -m pip install anthropic openai, and the environment variables
ANTHROPIC_API_KEY (for Claude models) and OPENAI_API_KEY (for ChatGPT models).
No system prompt, temperature, thinking or effort setting: each model runs with its defaults.
"""
import argparse, csv, datetime, glob, os, re, sys, time

CLAUDE_MODEL = "claude-opus-5-5"
CHATGPT_MODEL = "gpt-6-astra"
MAX_TOKENS_CLAUDE = 16000
MAX_TOKENS_CHATGPT = 25000
PROMPT_DIR = "prompts"
OUT_DIR = "outputs"
LOG_FILE = "outputs/generation_log.csv"

def well_formed(t):
    t = t.strip()
    return t.startswith("=== DIAGRAM ===") and "=== DESCRIPTIONS ===" in t and "@enduml" in t

def counts(t):
    d = t.split("=== DESCRIPTIONS ===")[0]
    ucs = len(re.findall(r'^\s*usecase\b', d, re.M | re.I)) + len(re.findall(r'^\s*\([^)]+\)\s+as\s+\w+', d, re.M))
    actors = len(re.findall(r'^\s*actor\b', d, re.M | re.I))
    descs = len(re.findall(r'^Use case:', t, re.M))
    return ucs, actors, descs

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--only", default="")
    a = ap.parse_args()
    files = sorted(glob.glob(f"{PROMPT_DIR}/S2-*.txt"))
    if len(files) != 24:
        sys.exit(f"Expected 24 prompt files in '{PROMPT_DIR}', found {len(files)}.")
    want = {x.strip() for x in a.only.split(",") if x.strip()}
    jobs = []
    for f in files:
        mid = os.path.basename(f)[:-4]
        if want and mid not in want:
            continue
        gen = "Claude" if mid.startswith("S2-CL") else "ChatGPT"
        out = f"{OUT_DIR}/{gen}/{mid}.txt"
        if os.path.exists(out) and os.path.getsize(out) > 0:
            print(f"{mid}: already saved, skipped"); continue
        jobs.append((mid, gen, open(f, encoding="utf-8").read(), out))
    if want and not jobs and not any(os.path.exists(f"{OUT_DIR}/{g}/{m}.txt") for m in want for g in ("Claude","ChatGPT")):
        sys.exit("None of the ids given with --only were found.")
    for mid, gen, prompt, out in jobs:
        print(f"{mid} -> {gen}: request built, {len(prompt)} characters")
    if a.dry_run or not jobs:
        print("Dry run: nothing sent." if a.dry_run else "Nothing to send."); return
    clients = {}
    if any(g == "Claude" for _, g, _, _ in jobs):
        import anthropic
        if not os.environ.get("ANTHROPIC_API_KEY"): sys.exit("Set ANTHROPIC_API_KEY first.")
        clients["Claude"] = anthropic.Anthropic()
    if any(g == "ChatGPT" for _, g, _, _ in jobs):
        import openai
        if not os.environ.get("OPENAI_API_KEY"): sys.exit("Set OPENAI_API_KEY first.")
        clients["ChatGPT"] = openai.OpenAI()
    os.makedirs(f"{OUT_DIR}/Claude", exist_ok=True); os.makedirs(f"{OUT_DIR}/ChatGPT", exist_ok=True)
    new = not os.path.exists(LOG_FILE)
    log = open(LOG_FILE, "a", newline="", encoding="utf-8"); w = csv.writer(log)
    if new:
        w.writerow(["model_id", "generator", "utc_time", "model_requested", "model_returned", "status",
                    "input_tokens", "output_tokens", "seconds", "well_formed", "use_cases_in_diagram",
                    "actors_in_diagram", "descriptions", "reply_file"])
    for mid, gen, prompt, out in jobs:
        t0 = time.time()
        try:
            if gen == "Claude":
                r = clients[gen].messages.create(model=CLAUDE_MODEL, max_tokens=MAX_TOKENS_CLAUDE,
                                                 messages=[{"role": "user", "content": prompt}])
                text = "".join(b.text for b in r.content if b.type == "text")
                status, uin, uout, ret, req = r.stop_reason, r.usage.input_tokens, r.usage.output_tokens, r.model, CLAUDE_MODEL
            else:
                r = clients[gen].responses.create(model=CHATGPT_MODEL, input=prompt, max_output_tokens=MAX_TOKENS_CHATGPT)
                text = r.output_text or ""
                status = r.status + (":" + str(r.incomplete_details.reason) if r.status == "incomplete" and r.incomplete_details else "")
                uin, uout, ret, req = r.usage.input_tokens, r.usage.output_tokens, r.model, CHATGPT_MODEL
        except Exception as e:
            print(f"{mid}: ERROR {type(e).__name__}: {e}"); continue
        secs = round(time.time() - t0, 1)
        open(out, "w", encoding="utf-8").write(text)
        ok = well_formed(text); ucs, acts, descs = counts(text)
        w.writerow([mid, gen, datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds"), req, ret,
                    status, uin, uout, secs, "yes" if ok else "NO", ucs, acts, descs, out]); log.flush()
        print(f"{mid}: {status}, {secs}s, well formed: {'yes' if ok else 'NO'}, "
              f"use cases {ucs}, actors {acts}, descriptions {descs}")
    log.close()

if __name__ == "__main__":
    main()
