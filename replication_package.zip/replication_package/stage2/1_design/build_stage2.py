"""Stage 2 corpus design: 24 realistic-size models, 3 planted antipattern instances each.
Seed 20261016. Writes design_KEEP_PRIVATE.csv, prompts/<id>.txt, template and summary."""
import random, csv, os, itertools, collections, re
random.seed(20261016)
SLOTDIR = '/home/claude/production_pack/prompts_v1.0'
def slots(ap):
    t = open(f'{SLOTDIR}/{ap}_prompts_v1.0.txt').read()
    out = {}
    for m in re.finditer(r'=== SLOT (\w+) ===\n(.*?)(?=\n=== SLOT|\Z)', t, re.S):
        out[m.group(1)] = m.group(2).strip()
    return out
S = {ap: slots(ap) for ap in ['AP1','AP2','AP5','AP6','AP17','AP22']}
# instance variants per antipattern and type (slot codes from stage 1)
VARIANTS = {
 'AP1': {'near miss': ['P2A','P2B'], 'acceptable': ['P3'], 'problem': ['P4']},
 'AP2': {'near miss': ['P2'], 'acceptable': ['P3'], 'problem': ['P4A','P4B']},
 'AP5': {'near miss': ['P2A','P2B'], 'acceptable': ['P3'], 'problem': ['P4']},
 'AP6': {'near miss': ['NM'], 'acceptable': ['P3A'], 'problem': ['P4A','P4B','P4C']},
 'AP17': {'near miss': ['P2A','P2B'], 'acceptable': ['P3'], 'problem': ['P4A','P4B']},
 'AP22': {'near miss': ['P2'], 'acceptable': ['P3A','P3B'], 'problem': ['P4A','P4B']},
}
# AP6 near miss: an extension of one base use case with no actor (stage 1 used the AP2 near-miss model for this)
S['AP6']['NM'] = S['AP2']['P2']
UCS = {'AP1':3,'AP2':3,'AP5':3,'AP6':3,'AP17':2,'AP22':2}
DOMAINS = ["a public library book loan and reservation system",
 "a dental clinic appointment and billing system",
 "a city bicycle-sharing system",
 "a university course registration system",
 "a hotel room booking and guest services system",
 "a veterinary clinic patient and appointment system",
 "a community theatre ticketing system",
 "a household waste collection and recycling service system",
 "a coworking space desk and meeting-room booking system",
 "a driving school lesson and test booking system",
 "a food bank donation and distribution system",
 "a municipal building permit application system"]
GENS = ['Claude','ChatGPT']
TYPES = ['near miss','acceptable','problem']
APS = list(VARIANTS)
def assign():
    # per generator: 12 models x 3 instances = 36 = 6 APs x (2 NM, 2 A, 2 P)
    for _ in range(20000):
        models = {}
        ok = True
        for g in GENS:
            pool = [(ap,t) for ap in APS for t in TYPES for _ in range(2)]
            random.shuffle(pool)
            ms = [[] for _ in range(12)]
            for inst in pool:
                cand = [i for i in range(12) if len(ms[i]) < 3 and inst[0] not in [a for a,_ in ms[i]]]
                if not cand: ok = False; break
                random.choice(cand) and None
                ms[min(cand, key=lambda i: (len(ms[i]), random.random()))].append(inst)
            if not ok: break
            if any(len({t for _,t in m}) == 1 for m in ms): ok = False; break
            models[g] = ms
        if ok: return models
    raise SystemExit('no assignment')
models = assign()
rot = collections.defaultdict(itertools.count)
rows = []
dom_order = {g: random.sample(DOMAINS, 12) for g in GENS}
n = 0
for gi, g in enumerate(GENS):
    for k, inst in enumerate(models[g]):
        n += 1
        mid = f'S2-{g[:2].upper()}-{k+1:02d}'
        frags = []
        for ap, t in inst:
            vs = VARIANTS[ap][t]
            v = vs[next(rot[(ap,t)]) % len(vs)]
            frags.append((ap, t, v))
        random.shuffle(frags)
        fuc = sum(UCS[a] for a,_,_ in frags)
        total = random.randint(max(9, fuc + 2), 12)
        n_actors = random.choice([2,3,3,4]) if total >= 10 else random.choice([2,3])
        rows.append(dict(model_id=mid, generator=g, domain=dom_order[g][k], total_use_cases=total,
                         actors=n_actors, filler_use_cases=total - fuc,
                         **{f'frag{i+1}': f'{a} {t} ({v})' for i,(a,t,v) in enumerate(frags)}, _frags=frags))
# ---- prompt text
HEAD = """You are an experienced requirements engineer. Create one UML use case
model of realistic size for this system: {DOMAIN}

SIZE
- Exactly {N} use cases and exactly {A} actors. Every actor is a different
  human role.

CONTENT
The model contains the {K} fragments described below, and {F} other use
cases. Each fragment uses its own use cases: no use case belongs to two
fragments. Name the actors as suits the system; "Actor 1", "Actor 2" and so on
below only say which actor plays which part.
{FRAGS}
OTHER USE CASES
- The {F} other use cases are ordinary services of the system. Each is
  associated with one or more actors by a plain (undirected) association, is
  one complete goal of that actor, and is named verb + object.
- Such a use case has no include, extend or generalization relationship.
  It deals with something that no other use case creates, changes or
  removes. No precondition of such a use case states something that a
  postcondition of another use case states, and the reverse. Its name and
  goal are clearly different from those of every other use case.
- Every actor is associated with at least one use case.
- Apart from what the fragments require, there are no relationships between
  use cases and no abstract use cases.

ORDER
- In the diagram and in the descriptions, list the use cases in an order that
  mixes the fragments and the other use cases. Do not group the use cases
  of a fragment together.

NAMING RULES
- Every actor is a human role. Do not use a personal name, a device, a
  technical component, or a generic name such as "User".
- No use case may be: Log in / Sign in / Authenticate; named with the verbs
  Manage, Handle, Process or Maintain; or an internal system function (e.g.
  Validate, Calculate, Check, Store). No two use cases may be create / view /
  update / delete operations on the same thing, unless a fragment asks for
  it.

DESCRIPTION RULES (one description per use case, using the template below)
- Each use case: main flow of 3 to 7 numbered steps, written out in full. A
  child's main flow is complete in itself; it does not say "as in the parent".
- Each step is an action by an actor on the system, or by the system. No
  steps between people only.
- Alternative flows: 0 to 2 per use case, each at most 3 steps.
- Preconditions and postconditions describe system states. Postconditions
  describe the successful outcome only. Each use case has 1 to 3
  preconditions and 1 to 3 postconditions. No precondition or postcondition
  names a use case or says that a use case has run or will run, unless a
  fragment asks for it.
- Goals, main flows and alternative flows never mention another use case,
  unless a fragment asks for it. The description of an extended use case
  does not mention the use case that extends it, and the description of a
  parent does not mention its children.
- Do not mention screens, buttons, databases, technologies or algorithms.
- The "Kind" line says "concrete" or "abstract". The "Specializes" line
  appears only in a child use case and names its parent. A use case that
  extends another has an "Extends" line naming the use case or use cases it
  extends and a "Condition" line stating when it applies; the condition holds
  on some runs of an extended use case and not on others.
- "Primary actor" names the actor or actors associated with the use case in
  the diagram. For a child whose parent is associated with an actor, write
  "<actor> (through the parent)". For an extension use case with no actor,
  write "None (extension use case)". For any other use case with no actor,
  write "None".
- The diagram and the descriptions must agree exactly.
- Write the diagram as PlantUML text inside a system boundary (rectangle). Do
  not render or draw it, and do not put notes in it: a condition appears only
  in the description. Associations are plain (undirected): Actor -- UC.
  Include is written Base .> Included : <<include>>. Extend is written
  Extension .> Base : <<extend>>. Generalization is written Child --|> Parent.
  An abstract use case, and only an abstract use case, is marked <<abstract>>.
- Describe only what happens. Do not state or suggest anywhere in the model
  that a use case is independent, standalone, reusable, optional, mandatory,
  common, redundant, complete, incomplete, valuable, a step, a part, a stage,
  a phase, a sub-function or a prerequisite of anything, and do not use the
  words "always", "every time", "sequence", "depends", "temporary" or
  "lasting".
- Do not explain, label or comment on the design anywhere in the output, and
  do not mention fragments.
- Use plain text only: no markdown headings, bold text or tables.

OUTPUT FORMAT
Your reply begins with the line === DIAGRAM === and contains only the two
sections below.
=== DIAGRAM ===
<PlantUML use case diagram, from @startuml to @enduml>
=== DESCRIPTIONS ===
Use case: <name>
Kind: <concrete or abstract>
Specializes: <parent>                  (only for a child use case)
Primary actor: <actor or actors>
Extends: <use case(s) it extends>      (only for an extension use case)
Condition: <when it applies>          (only for an extension use case)
Goal: <one sentence>
Preconditions: <list>
Main flow: <numbered steps>
Alternative flows: <list, or "None">
Postconditions: <list>
"""
def frag_text(i, ap, v, actor, actor2):
    s = S[ap][v]
    if ap in ('AP1','AP2'):
        base = (f"- 2 base use cases, each associated with {actor} by a plain association and\n"
                f"  each one complete goal of that actor, named verb + object.")
        s = s.replace('the actor', actor)
    elif ap == 'AP6':
        base = (f"- 2 base use cases, each associated with {actor} by a plain association and\n"
                f"  each one complete goal of that actor, named verb + object.")
        s = s.replace('Exactly 1 actor. ', '').replace('Exactly 2 actors. ', '')
        s = s.replace('Add a second actor (a different human role) and exactly 1\n  further use case', f'Add exactly 1 further use case')
        s = s.replace('the second actor', actor2).replace('The second actor', actor2).replace('that actor', actor2)
        s = s.replace('the actor', actor).replace('The actor', actor)
    elif ap == 'AP5':
        base = (f"- 1 parent use case and 2 child use cases. Each child is related to the\n"
                f"  parent by generalization (the child specializes the parent). Each child\n"
                f"  is a kind of the parent: it delivers the parent's service in a more\n"
                f"  specific way. The three are clearly different services or kinds of\n"
                f"  service: no two of them are two names for the same thing. Each is named\n"
                f"  verb + object. The actor in this fragment is {actor}.")
        s = s.replace('the actor', actor)
    else:  # AP17, AP22
        base = (f"- 2 use cases, each associated with {actor} by a plain association and\n"
                f"  named verb + object.")
        s = s.replace('the actor', actor)
        if ap == 'AP17':
            s += "\n- The description of each of these two use cases never mentions the other."
    import textwrap
    def wrap(block):
        out=[]
        for para in re.split(r'\n(?=- )', block):
            para=' '.join(para.split())
            out.append(textwrap.fill(para, 78, subsequent_indent='  '))
        return '\n'.join(out)
    return f"\nFRAGMENT {i}\n{wrap(base)}\n{wrap(s)}\n"
os.makedirs('prompts', exist_ok=True)
for r in rows:
    frags = r.pop('_frags')
    k = len(frags)
    texts = []
    dedicated = any(ap == 'AP6' and v in ('P4A','P4C') for ap,_,v in frags)
    if dedicated and r['actors'] < 3: r['actors'] = 3
    usable = r['actors'] - (1 if dedicated else 0)
    for i, (ap, t, v) in enumerate(frags, 1):
        actor = f'Actor {((i-1) % usable) + 1}'
        actor2 = f'Actor {r["actors"]}' if dedicated else ''
        texts.append(frag_text(i, ap, v, actor, actor2))
    p = HEAD.format(DOMAIN=r['domain'], N=r['total_use_cases'], A=r['actors'], K=k,
                    F=r['filler_use_cases'], FRAGS=''.join(texts))
    open(f'prompts/{r["model_id"]}.txt', 'w').write(p)
with open('design_KEEP_PRIVATE.csv', 'w', newline='') as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
c = collections.Counter()
for r in rows:
    for i in (1,2,3):
        ap, rest = r[f'frag{i}'].split(' ', 1); t = rest.rsplit(' (',1)[0]; c[(r['generator'], ap, t)] += 1
print(len(rows), 'models')
for g in GENS:
    print(g, {ap: [c[(g,ap,t)] for t in TYPES] for ap in APS})
print(collections.Counter(r['total_use_cases'] for r in rows), collections.Counter(r['actors'] for r in rows))
