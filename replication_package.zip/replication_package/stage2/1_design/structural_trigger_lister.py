import re,sys,csv,collections
def parse(path):
    t=open(path,encoding='utf-8').read()
    d=t.split('=== DESCRIPTIONS ===')[0]
    names={}; abstract=set()
    for m in re.finditer(r'usecase\s+"([^"]+)"\s+as\s+(\w+)([^\n]*)',d):
        names[m.group(2)]=m.group(1)
        if 'abstract' in m.group(3).lower(): abstract.add(m.group(2))
    actors={}
    for m in re.finditer(r'actor\s+"([^"]+)"\s+as\s+(\w+)',d): actors[m.group(2)]=m.group(1)
    for m in re.finditer(r'actor\s+(\w+)\s*$',d,re.M): actors[m.group(1)]=m.group(1)
    inc=[];ext=[];gen=[];assoc=[]
    for a,b in re.findall(r'(\w+)\s*\.+>\s*(\w+)\s*:\s*<<include>>',d): inc.append((a,b))
    for a,b in re.findall(r'(\w+)\s*\.+>\s*(\w+)\s*:\s*<<extend>>',d): ext.append((a,b))
    for a,b in re.findall(r'(\w+)\s*-+\|>\s*(\w+)',d): gen.append((a,b))
    for a,b in re.findall(r'^\s*(\w+)\s*-{1,2}\s*(\w+)\s*$',d,re.M):
        if a in actors: assoc.append((a,b))
        elif b in actors: assoc.append((b,a))
    # kinds from descriptions
    for m in re.finditer(r'Use case:\s*(.+)\n(?:.*\n)?Kind:\s*(\w+)',t):
        if m.group(2).lower()=='abstract':
            for k,v in names.items():
                if v.strip()==m.group(1).strip(): abstract.add(k)
    N=lambda x: names.get(x,actors.get(x,x))
    ua=collections.defaultdict(set)
    for a,u in assoc: ua[u].add(a)
    trig=[]
    ic=collections.Counter(b for a,b in inc)
    for u,c in ic.items():
        if c==1 and not ua[u]: trig.append(f"AP1 trigger: '{N(u)}' included only by '{N([a for a,b in inc if b==u][0])}', no actor")
        else: trig.append(f"(include of '{N(u)}': by {c}, actors {len(ua[u])})")
    eb=collections.defaultdict(set)
    for a,b in ext: eb[a].add(b)
    for e,bs in eb.items():
        if len(bs)>1: trig.append(f"AP2 trigger: '{N(e)}' extends {', '.join(N(b) for b in bs)}")
        if ua[e]: trig.append(f"AP6 trigger: extension '{N(e)}' associated with {', '.join(N(x) for x in ua[e])}")
        if len(bs)==1 and not ua[e]: trig.append(f"(extension '{N(e)}' of one base, no actor)")
    par=collections.defaultdict(list)
    for c,p in gen: par[p].append(c)
    for p,cs in par.items():
        s=f"'{N(p)}' {'abstract' if p in abstract else 'concrete'}, actors {[N(x) for x in ua[p]]}, children {[N(c) for c in cs]} child-actors {[ [N(x) for x in ua[c]] for c in cs]}"
        trig.append(("AP5 trigger: " if p not in abstract and ua[p] else "(generalization: ")+s+("" if p not in abstract and ua[p] else ")"))
    unassoc=[N(u) for u in names if not ua[u] and u not in [b for a,b in inc] and u not in eb and u not in [c for c,p in gen]]
    return len(names),len(actors),trig,unassoc
if __name__=='__main__':
    des={r['model_id']:r for r in csv.DictReader(open('/home/claude/stage2/design_KEEP_PRIVATE.csv'))}
    for p in sys.argv[1:]:
        mid=p.split('/')[-1][:-4]; r=des[mid]
        n,a,tr,un=parse(p)
        print(f"== {mid} UC {n}/{r['total_use_cases']} actors {a}/{r['actors']} | {r['frag1']} | {r['frag2']} | {r['frag3']}")
        for x in tr: print('   ',x)
        if un: print('    no actor:',un)
