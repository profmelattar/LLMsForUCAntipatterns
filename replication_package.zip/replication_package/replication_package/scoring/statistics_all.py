"""Every statistic reported in the paper's statistical tables (Tables 6-15).

Run from the package root:   python scoring/statistics_all.py
Needs numpy, scipy and statsmodels (pip install numpy scipy statsmodels).
Writes scoring/statistics_all.json and prints a readable summary.

Scoring unit (Section 4.8): every model is judged against all six antipatterns.
A problem counts as detected when the judge gives a PROBLEM verdict for its
antipattern that names every construct in problem_constructs. Every other
PROBLEM verdict, for any antipattern, is a false alarm. A false alarm on a pair
that also holds a detected problem (stage 2, model N15) is still counted.
"""
import csv, json, math, os, statistics, sys
from collections import Counter
import numpy as np
from scipy import stats
from statsmodels.stats.contingency_tables import cochrans_q, mcnemar
from statsmodels.stats.multitest import multipletests
from statsmodels.stats.proportion import proportion_confint

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from parse_reply import parse_reply, APS

ROOT = os.path.join(HERE, '..')
J = ['Claude', 'ChatGPT', 'Gemini']
RUNS = (1, 2, 3)
OUT = {}


def wilson(k, n):
    lo, hi = proportion_confint(k, n, method='wilson')
    return [k, n, round(100 * k / n, 1), round(100 * lo, 1), round(100 * hi, 1)]


def newcombe_unpaired(k1, n1, k2, n2):
    p1, p2 = k1 / n1, k2 / n2
    l1, u1 = proportion_confint(k1, n1, method='wilson'); l2, u2 = proportion_confint(k2, n2, method='wilson')
    d = p1 - p2
    return d, d - math.sqrt((p1 - l1) ** 2 + (u2 - p2) ** 2), d + math.sqrt((u1 - p1) ** 2 + (p2 - l2) ** 2)


def newcombe_paired(x, y):
    """Newcombe (1998) method 10: CI for p(x) - p(y) on paired binary data."""
    n = len(x)
    a = sum(1 for i, j in zip(x, y) if i and j); b = sum(1 for i, j in zip(x, y) if i and not j)
    c = sum(1 for i, j in zip(x, y) if not i and j); dd = n - a - b - c
    p1, p2 = (a + b) / n, (a + c) / n
    l1, u1 = proportion_confint(a + b, n, method='wilson'); l2, u2 = proportion_confint(a + c, n, method='wilson')
    den = (a + b) * (c + dd) * (a + c) * (b + dd)
    phi = (a * dd - b * c) / math.sqrt(den) if den > 0 else 0.0
    d = p1 - p2
    lo = d - math.sqrt(max(0.0, (p1 - l1) ** 2 - 2 * phi * (p1 - l1) * (u2 - p2) + (u2 - p2) ** 2))
    hi = d + math.sqrt(max(0.0, (u1 - p1) ** 2 - 2 * phi * (u1 - p1) * (p2 - l2) + (p2 - l2) ** 2))
    return d, lo, hi


def cohen_h(p1, p2):
    return 2 * math.asin(math.sqrt(p1)) - 2 * math.asin(math.sqrt(p2))


def fleiss_from_counts(c, n=3):
    N = sum(c.values())
    Po = sum(c.get(k, 0) * (k * (k - 1) + (n - k) * (n - k - 1)) / (n * (n - 1)) for k in range(n + 1)) / N
    p = sum(k * c.get(k, 0) for k in range(n + 1)) / (N * n); Pe = p * p + (1 - p) * (1 - p)
    return ((Po - Pe) / (1 - Pe) if Pe < 1 else float('nan')), Po, Pe


def fleiss(rows):
    return fleiss_from_counts(Counter(int(sum(r)) for r in rows))[0]


def boot_kappa(rows, B=5000, seed=20261030, per_model=6):
    """Percentile bootstrap that resamples whole models (the six pairs of a model stay together)."""
    rows = np.array(rows, dtype=int).reshape(-1, per_model, np.array(rows).shape[1])
    rng = np.random.default_rng(seed); vals = []
    for _ in range(B):
        k = fleiss(rows[rng.integers(0, len(rows), len(rows))].reshape(-1, rows.shape[2]))
        if k == k: vals.append(k)
    return [round(float(x), 3) for x in np.percentile(vals, [2.5, 97.5])]


def load(stage):
    if stage == 1:
        key = list(csv.DictReader(open(os.path.join(ROOT, 'stage1', 'stage1_construction_key.csv'), encoding='utf-8')))
        units = [dict(nid=r['neutral_id'], ap=r['antipattern'], type=r['model_type'], cons=r['problem_constructs'], gen=r['generator']) for r in key]
        models = sorted(r['neutral_id'] for r in key)
        rdir = os.path.join(ROOT, 'stage1', '5_judge_replies')
    else:
        key = list(csv.DictReader(open(os.path.join(ROOT, 'stage2', 'stage2_construction_key.csv'), encoding='utf-8')))
        units = [dict(nid=r['neutral_id'], ap=r['antipattern'], type=r['type'], cons=r['problem_constructs'], gen=r['generator']) for r in key]
        models = sorted({r['neutral_id'] for r in key})
        rdir = os.path.join(ROOT, 'stage2', '6_judge_replies')
    rep = {(j, m, r): parse_reply(open(os.path.join(rdir, j, f'{m}_r{r}.txt'), encoding='utf-8').read())[1] for j in J for m in models for r in RUNS}
    return units, models, rep


def score(stage):
    units, models, rep = load(stage)
    probs = {(u['nid'], u['ap']): u['cons'] for u in units if u['type'] == 'problem'}
    caught, fa = {}, {}   # caught[(j,m,a,r)] bool ; fa[(j,m,a,r)] = number of unmatched PROBLEM verdicts
    for (j, m, r), fs in rep.items():
        for a in APS:
            pv = [f for f in fs if f['Antipattern'] == a and f['Verdict'] == 'PROBLEM']
            used = set()
            if (m, a) in probs:
                names = [x.strip().lower() for x in probs[(m, a)].split(';')]
                hit = [i for i, f in enumerate(pv) if all(x in f['Constructs'].lower() for x in names)]
                caught[(j, m, a, r)] = bool(hit); used = set(hit)
            fa[(j, m, a, r)] = len([i for i in range(len(pv)) if i not in used])
    return units, models, rep, probs, caught, fa


res = {}
for stage in (1, 2):
    units, models, rep, probs, caught, fa = score(stage)
    P = sorted(probs); pairs = [(m, a) for m in models for a in APS]
    own = {(u['nid'], u['ap']) for u in units}
    S = {'n_models': len(models), 'n_pairs': len(pairs), 'n_problems': len(P)}
    det_run = {j: [sum(caught[(j, m, a, r)] for m, a in P) for r in RUNS] for j in J}
    fa_run = {j: [sum(1 for m, a in pairs if fa[(j, m, a, r)]) for r in RUNS] for j in J}
    fa_run_own = {j: [sum(1 for m, a in pairs if fa[(j, m, a, r)] and (m, a) in own) for r in RUNS] for j in J}
    fa_run_off = {j: [sum(1 for m, a in pairs if fa[(j, m, a, r)] and (m, a) not in own) for r in RUNS] for j in J}
    det_maj = {j: [int(sum(caught[(j, m, a, r)] for r in RUNS) >= 2) for m, a in P] for j in J}
    fa_maj = {j: [int(sum(1 for r in RUNS if fa[(j, m, a, r)]) >= 2) for m, a in pairs] for j in J}
    det_maj['Panel'] = [int(sum(det_maj[j][i] for j in J) >= 2) for i in range(len(P))]
    fa_maj['Panel'] = [int(sum(fa_maj[j][i] for j in J) >= 2) for i in range(len(pairs))]
    S['per_run'] = dict(detected=det_run, false_alarms=fa_run, false_alarms_scored=fa_run_own, false_alarms_off_target=fa_run_off)
    S['off_target_majority'] = {j: [(m, a) for i, (m, a) in enumerate(pairs) if fa_maj[j][i] and (m, a) not in own] for j in J}
    perf = {}
    for j in J + ['Panel']:
        tp = sum(det_maj[j]); fn = len(P) - tp; nfa = sum(fa_maj[j])
        prec = wilson(tp, tp + nfa); sens = wilson(tp, len(P))
        f1 = 2 * (tp / (tp + nfa)) * (tp / len(P)) / ((tp / (tp + nfa)) + (tp / len(P)))
        perf[j] = dict(detected=tp, missed=fn, false_alarms=nfa, sensitivity=sens, precision=prec, f1=round(f1, 3))
    S['performance_majority'] = perf
    # agreement
    agr = {}
    for j in J:
        rows = [[int((caught.get((j, m, a, r), False)) if (m, a) in probs else int(fa[(j, m, a, r)] > 0)) for r in RUNS] for m, a in pairs]
        c = Counter(sum(r) for r in rows); k, Po, Pe = fleiss_from_counts(c)
        agr[f'{j}, three runs'] = dict(N=len(rows), dist=[c.get(i, 0) for i in range(4)], Po=round(Po, 4), Pe=round(Pe, 4), kappa=round(k, 3), ci=boot_kappa(rows))
    rows = [[(det_maj[j][P.index((m, a))] if (m, a) in probs else fa_maj[j][i]) for j in J] for i, (m, a) in enumerate(pairs)]
    c = Counter(sum(r) for r in rows); k, Po, Pe = fleiss_from_counts(c)
    agr['Three judges, majority verdicts'] = dict(N=len(rows), dist=[c.get(i, 0) for i in range(4)], Po=round(Po, 4), Pe=round(Pe, 4), kappa=round(k, 3), ci=boot_kappa(rows))
    S['agreement'] = agr
    # paired tests across judges
    tests = {}
    for label, vec in (('detection', det_maj), ('false alarms', fa_maj)):
        mat = np.array([vec[j] for j in J]).T
        q = cochrans_q(mat) if mat.sum() else None
        t = dict(cochran_Q=(round(float(q.statistic), 2) if q else 0.0), df=2, p=(round(float(q.pvalue), 4) if q else 1.0), n_items=len(mat), pairwise={})
        raw = []
        for a_, b_ in (('Claude', 'ChatGPT'), ('Claude', 'Gemini'), ('ChatGPT', 'Gemini')):
            x, y = vec[a_], vec[b_]
            b01 = sum(1 for i, k2 in zip(x, y) if i and not k2); b10 = sum(1 for i, k2 in zip(x, y) if k2 and not i)
            p = mcnemar([[0, b01], [b10, 0]], exact=True).pvalue
            d, lo, hi = newcombe_paired(x, y)
            raw.append(p)
            t['pairwise'][f'{a_} vs {b_}'] = dict(discordant=[b01, b10], p=round(float(p), 4), rd_pp=[round(100 * d, 1), round(100 * lo, 1), round(100 * hi, 1)], h=round(cohen_h(sum(x) / len(x), sum(y) / len(y)), 2))
        for (kname, v), ph in zip(t['pairwise'].items(), multipletests(raw, method='holm')[1]):
            v['p_holm'] = round(float(ph), 4)
        tests[label] = t
    S['tests'] = tests
    gen = {u['nid']: u['gen'] for u in units}
    bygen = {}
    for j in J:
        for gname in ('Claude', 'ChatGPT'):
            prob_g = [i for i, (m, a) in enumerate(P) if gen[m] == gname]
            bygen[f'{j} on {gname}-generated'] = dict(problems=len(prob_g), missed=sum(1 - det_maj[j][i] for i in prob_g),
                                                      false_alarms=sum(fa_maj[j][i] for i, (m, a) in enumerate(pairs) if gen[m] == gname))
        if j in ('Claude', 'ChatGPT'):
            own = bygen[f'{j} on {j}-generated']; oth = bygen[f"{j} on {'ChatGPT' if j == 'Claude' else 'Claude'}-generated"]
            _, pf = stats.fisher_exact([[own['missed'], own['problems'] - own['missed']], [oth['missed'], oth['problems'] - oth['missed']]])
            bygen[f'{j}: own vs other, Fisher p (misses)'] = round(float(pf), 3)
    S['by_generator'] = bygen
    # controls
    nm = [(u['nid'], u['ap']) for u in units if u['type'] == 'near miss']
    S['controls'] = dict(near_miss_items=len(nm), near_miss_judgements=len(nm) * 9,
                         near_miss_problem_verdicts_own_ap=sum(1 for j in J for m, a in nm for r in RUNS if fa[(j, m, a, r)]),
                         near_miss_reported_any_run={j: {ap: sum(1 for m, a in nm if a == ap and any(any(f['Antipattern'] == a for f in rep[(j, m, r)]) for r in RUNS)) for ap in ('AP17', 'AP22')} for j in J},
                         near_miss_counts={ap: sum(1 for m, a in nm if a == ap) for ap in APS})
    if stage == 1:
        clean = [u['nid'] for u in units if u['type'] == 'clean']
        S['controls']['clean_models'] = len(clean)
        S['controls']['clean_findings'] = sum(len(rep[(j, m, r)]) for j in J for m in clean for r in RUNS)
        S['controls']['clean_judgements'] = len(clean) * 9
    S['_vectors'] = dict(det_maj=det_maj, P=P)
    res[stage] = S

# stage 1 vs stage 2 detection (independent samples)
cmp = {}
for j in J + ['Panel']:
    a = sum(res[1]['_vectors']['det_maj'][j]); n1 = len(res[1]['_vectors']['P'])
    b = sum(res[2]['_vectors']['det_maj'][j]); n2 = len(res[2]['_vectors']['P'])
    _, p = stats.fisher_exact([[a, n1 - a], [b, n2 - b]])
    d, lo, hi = newcombe_unpaired(a, n1, b, n2)
    cmp[j] = dict(stage1=[a, n1], stage2=[b, n2], p=round(float(p), 3), rd_pp=[round(100 * d, 1), round(100 * lo, 1), round(100 * hi, 1)], h=round(cohen_h(a / n1, b / n2), 2))

# diagnostic run: AP5 problems, whole catalogue (stage 1, ChatGPT majority) vs AP5-only prompt
key1 = {r['neutral_id']: r for r in csv.DictReader(open(os.path.join(ROOT, 'stage1', 'stage1_construction_key.csv'), encoding='utf-8'))}
ap5p = sorted(m for m, r in key1.items() if r['antipattern'] == 'AP5' and r['model_type'] == 'problem')
ap5all = sorted(m for m, r in key1.items() if r['antipattern'] == 'AP5')
ddir = os.path.join(ROOT, 'stage1', '7_ap5_diagnostic', 'replies')


def caught_ap5(fs, m):
    names = [x.strip().lower() for x in key1[m]['problem_constructs'].split(';')]
    return any(f['Antipattern'] == 'AP5' and f['Verdict'] == 'PROBLEM' and all(x in f['Constructs'].lower() for x in names) for f in fs)


_, _, rep1, _, caught1, _ = score(1)
whole = [int(sum(caught1[('ChatGPT', m, 'AP5', r)] for r in RUNS) >= 2) for m in ap5p]
diag_runs = {m: [caught_ap5(parse_reply(open(os.path.join(ddir, f'{m}_r{r}.txt'), encoding='utf-8').read())[1], m) for r in RUNS] for m in ap5p}
diag = [int(sum(diag_runs[m]) >= 2) for m in ap5p]
diag_fa = sum(1 for m in ap5all if key1[m]['model_type'] != 'problem' for r in RUNS
              if any(f['Antipattern'] == 'AP5' and f['Verdict'] == 'PROBLEM' for f in parse_reply(open(os.path.join(ddir, f'{m}_r{r}.txt'), encoding='utf-8').read())[1]))
b01 = sum(1 for x, y in zip(whole, diag) if x and not y); b10 = sum(1 for x, y in zip(whole, diag) if y and not x)
dlog = list(csv.DictReader(open(os.path.join(ddir, 'trial_log.csv'), encoding='utf-8')))
diagnostic = dict(per_run_whole=[sum(caught1[('ChatGPT', m, 'AP5', r)] for m in ap5p) for r in RUNS],
                  per_run_ap5_only=[sum(diag_runs[m][r - 1] for m in ap5p) for r in RUNS],
                  majority_whole=sum(whole), majority_ap5_only=sum(diag), false_alarms_ap5_only=diag_fa,
                  same_models_missed=sum(1 for x, y in zip(whole, diag) if not x and not y),
                  mcnemar=dict(discordant=[b01, b10], p=round(float(mcnemar([[0, b01], [b10, 0]], exact=True).pvalue), 4)),
                  calls=len(dlog), zero_reasoning_calls=sum(1 for x in dlog if (x['reasoning_tokens'] or '0') == '0'))

# reasoning tokens: ChatGPT stage 1 responses on the AP5 problems
log = {x['custom_id']: x for x in csv.DictReader(open(os.path.join(ROOT, 'stage1', '5_judge_replies', 'ChatGPT', 'run_log.csv'), encoding='utf-8'))}
det_tok = [int(log[f'{m}_r{r}']['reasoning_tokens'] or 0) for m in ap5p for r in RUNS if caught1[('ChatGPT', m, 'AP5', r)]]
mis_tok = [int(log[f'{m}_r{r}']['reasoning_tokens'] or 0) for m in ap5p for r in RUNS if not caught1[('ChatGPT', m, 'AP5', r)]]
u = stats.mannwhitneyu(det_tok, mis_tok, alternative='two-sided')
cliff = lambda x, y: sum(int(a > b) - int(a < b) for a in x for b in y) / (len(x) * len(y))
rng = np.random.default_rng(20261030)
bd = [cliff(list(rng.choice(det_tok, len(det_tok))), list(rng.choice(mis_tok, len(mis_tok)))) for _ in range(5000)]
desc = lambda v: dict(n=len(v), median=float(statistics.median(v)), q1=float(np.percentile(v, 25)), q3=float(np.percentile(v, 75)), min=min(v), max=max(v))
# cluster bootstrap (resample models) for the response-level Cliff's delta
tok_m = {m: [int(log[f'{m}_r{r}']['reasoning_tokens'] or 0) for r in RUNS] for m in ap5p}
det_m = {m: [caught1[('ChatGPT', m, 'AP5', r)] for r in RUNS] for m in ap5p}
cb = []
for _ in range(5000):
    pick = rng.choice(ap5p, len(ap5p))
    dd = [t for m in pick for t, x in zip(tok_m[m], det_m[m]) if x]; mm = [t for m in pick for t, x in zip(tok_m[m], det_m[m]) if not x]
    if dd and mm: cb.append(cliff(dd, mm))
# per-model analysis: mean tokens per model, grouped by the majority verdict
mod_det = [float(np.mean(tok_m[m])) for m in ap5p if sum(det_m[m]) >= 2]
mod_mis = [float(np.mean(tok_m[m])) for m in ap5p if sum(det_m[m]) < 2]
um = stats.mannwhitneyu(mod_det, mod_mis, alternative='two-sided')
tokens = dict(detected=desc(det_tok), missed=desc(mis_tok), U_responses=float(u.statistic), p_responses=round(float(u.pvalue), 4),
              cliffs_delta=round(cliff(det_tok, mis_tok), 2), cliffs_ci_cluster=[round(float(x), 2) for x in np.percentile(cb, [2.5, 97.5])],
              per_model=dict(n_detected=len(mod_det), n_missed=len(mod_mis), median_detected=round(float(np.median(mod_det))),
                             median_missed=round(float(np.median(mod_mis))), U=float(um.statistic), p=round(float(um.pvalue), 3),
                             cliffs_delta=round(cliff(mod_det, mod_mis), 2)))

for s in (1, 2):
    res[s].pop('_vectors')
OUT = dict(stage1=res[1], stage2=res[2], stage_comparison=cmp, diagnostic=diagnostic, reasoning_tokens=tokens)
json.dump(OUT, open(os.path.join(HERE, 'statistics_all.json'), 'w'), indent=1, default=list)
print(json.dumps(OUT, indent=1, default=list))
