"""Random, balanced assignment of corpus generators to domains (Tier 1, stage 1).
Each antipattern: 5 domains per generator. Each domain: 6 antipatterns per generator.
Method: start from a balanced matrix, then apply random margin-preserving swaps.
Seed is fixed so the table can be reproduced."""
import random, csv
SEED = 20261010
APS = [f"AP{i}" for i in range(1, 13)]
DOMAINS = ["blood donation scheduling", "car sharing", "building maintenance requests",
           "school field-trip permission and payment", "produce auction",
           "museum guided-tour booking", "pharmacy prescription refill",
           "conference paper submission and review", "marina berth rental",
           "sports facility court booking"]
rng = random.Random(SEED)
m = [[(r + c) % 2 for c in range(10)] for r in range(12)]
for _ in range(20000):
    r1, r2 = rng.sample(range(12), 2); c1, c2 = rng.sample(range(10), 2)
    if m[r1][c1] == m[r2][c2] and m[r1][c2] == m[r2][c1] and m[r1][c1] != m[r1][c2]:
        m[r1][c1], m[r1][c2] = m[r1][c2], m[r1][c1]
        m[r2][c1], m[r2][c2] = m[r2][c2], m[r2][c1]
assert all(sum(row) == 5 for row in m) and all(sum(m[r][c] for r in range(12)) == 6 for c in range(10))
name = {0: "ChatGPT", 1: "Claude"}
with open("generator_assignment.csv", "w", newline="") as f:
    w = csv.writer(f); w.writerow(["Antipattern"] + [f"D{i+1}: {d}" for i, d in enumerate(DOMAINS)])
    for ap, row in zip(APS, m): w.writerow([ap] + [name[v] for v in row])
print("| AP | " + " | ".join(f"D{i+1}" for i in range(10)) + " |")
print("|---|" + "---|" * 10)
for ap, row in zip(APS, m): print(f"| {ap} | " + " | ".join("G" if v == 0 else "C" for v in row) + " |")
