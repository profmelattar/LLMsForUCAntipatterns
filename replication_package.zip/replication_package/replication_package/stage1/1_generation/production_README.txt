PRODUCTION PACK, built 10 October 2026 (seed 20261010; rebuild with build_pack.py)
Status: DRAFT until the researcher signs off the frozen prompts (see CHANGES_v1.0.txt).

prompts_v1.0/            The six frozen prompt sets: shared text plus slot lines.
CHANGES_v1.0.txt         Every wording difference between v1.0 and the last piloted version. Review this first.
production/ChatGPT/      THE CORPUS PROMPTS. 120 files, one per production run for ChatGPT.
production/Claude/       120 files, one per production run for Claude.
run_sheet_ChatGPT.csv    The order of work for ChatGPT, with columns to fill in.
run_sheet_Claude.csv     The same for Claude.
assignment_with_labels_KEEP_PRIVATE.csv
                         The answer key: model type and expected baseline result for every run.
                         Never show this file, or a run id, to an evaluating model.
outputs/                 Save each reply here. An empty file is already there for every run:
                         outputs/ChatGPT (120) and outputs/Claude (120).
                         Open the file with the run's name, paste the reply, save.
PROTOCOL.txt             The run procedure. Read before the first sitting.

THE CORPUS: 240 models = 24 sets x 10 production domains.
  Shared clean set (AP1 P1)                                   10
  AP1   P2A, P2B near misses; P3 acceptable; P4 problem       40
  AP2   P2 near miss (also the AP6 near miss); P3; P4 (kinds A, B rotated)   30
  AP5   P2A, P2B near misses; P3 acceptable; P4 problem       40
  AP6   P3A acceptable; P4 problem (kinds A, B, C rotated)    20
  AP17  P2A, P2B near misses; P3 acceptable; P4A, P4B problem 50
  AP22  P2 near miss; P3A, P3B acceptable; P4A, P4B problem   50
Each set: 5 models per generator. Each domain: 12 models per generator.
Run ids contain the prompt code (for example AP22-P4B-D07). They are for generation only.
Before evaluation every model gets a neutral id, drawn at random.
