PROMPT VERSION ARCHIVE - use case antipattern study
Compiled 10 October 2026. Prompts are corpus-generation prompts for stage 1 (minimal models).
{DOMAIN} is the only slot in the template files; the PILOT files have the pilot domains filled in.

AP1  Functional decomposition using the include relationship
  AP1_stage1_prompts_v0.2.txt   First piloted version. 5 prompts: P1 clean, P2A near miss (included by
                                two), P2B near miss (has an actor), P3 trigger acceptable, P4 trigger problem.
                                Piloted on ChatGPT (GPT-6), 10 Oct 2026. P3 failed: label not clear.
  AP1_stage1_prompts_v0.3.txt   Current. Changes from 0.2: P3 requires the actor to take part in at least
                                2 steps of the included use case and to supply its inputs; P4 relies on
                                information gathered earlier in the including use case; all prompts forbid
                                wording that argues a use case is independent/reusable/valuable; plain text
                                only. Piloted: all 5 on Claude (Opus 5.5), P3 and P4 on ChatGPT. All passed.
                                Awaiting the researcher's sign-off before freezing.
  PILOT_AP1_ready_prompts.txt           v0.2 with pilot domains
  PILOT2_AP1_ready_prompts_v0.3.txt     v0.3 with pilot domains

AP2  Extension use case extending multiple use cases
  AP2_stage1_prompts_v0.1.txt   First draft. 4 prompts: P2 near miss (extends one), P3 trigger acceptable,
                                P4A problem (different handling), P4B problem (general behavior).
                                Clean set shared with AP1 (AP1 prompt P1). Piloted on ChatGPT, 10 Oct 2026:
                                P2 pass, P3 pass, P4A pass on structure but named the base use cases in
                                steps and postconditions (one output rejected for format), P4B label unclear.
  AP2_P4B_interim_test_2026-10-10.txt   P4B redrafted for the reworded criterion 3 (extension performed on
                                every run). Tested once on ChatGPT (community garden): passed.
  AP2_stage1_prompts_v0.2.txt   Current. Changes from 0.1: diagram written as PlantUML text with no notes;
                                banned words extended (mandatory, common, always, every time); P3 adds
                                "only under a stated condition"; P4A describes branches by circumstances and
                                does not name the base use cases; P4B as in the interim test, plus no step
                                added to the base use cases just to mark where the extension applies.
                                Claude pilot in progress; P4A rerun on ChatGPT still owed.
  PILOT_AP2_ready_prompts_v0.1.txt      v0.1 with pilot domains
  PILOT_AP2_ready_prompts_v0.2.txt      v0.2 with pilot domains

Pilot domains (never used for production): veterinary clinic appointment system; municipal parking permit
system; university thesis submission system; bicycle repair shop job-tracking system; community garden plot
allocation system.

Assignment of generators to production domains: generator_assignment.csv, produced by assign_generators.py
(seed 20261010).

ADDED 10 October 2026 (evening)
AP5_stage1_prompts_v0.1.txt      AP5, one parent + one child. Piloted on ChatGPT; superseded (P4 unclear label).
PILOT_AP5_ready_prompts_v0.1.txt Ready-to-paste pilot prompts for AP5 v0.1. ap5_v01.json: same, keyed by prompt.
AP5_stage1_prompts_v0.2.txt      AP5, one parent + two children. Piloted on ChatGPT and Claude; passed.
PILOT_AP5_ready_prompts_v0.2.txt Ready-to-paste pilot prompts for AP5 v0.2. ap5_v02.json: same, keyed by prompt.
AP6_stage1_prompts_v0.1.txt      AP6, five slots. Piloted on ChatGPT; superseded.
PILOT_AP6_ready_prompts_v0.1.txt Ready-to-paste pilot prompts for AP6 v0.1. ap6_v01.json: same, keyed by prompt.
AP6_stage1_prompts_v0.2.txt      AP6, P3B removed, condition rule added. Piloted on Claude.
PILOT_AP6_ready_prompts_v0.2.txt Ready-to-paste pilot prompts for AP6 v0.2. ap6_v02.json: same, keyed by prompt.
AP6_P4A_thesis_v0.2.txt, AP6_P4C_garden_v0.2.txt  Single prompts as files (to avoid truncation when copying).

ADDED 10 October 2026 (late evening)
AP2_P4A_bicycle_v0.2.txt           Single prompt used for the owed ChatGPT rerun of AP2 P4A.
AP17_stage1_prompts_v0.1/0.2/0.3   AP17 master files. v0.3 is current (P2A example removed; P2B reworded).
AP17_P*_v0.1/0.2/0.3.txt           AP17 single prompts. ap17_v01.json, ap17_v02.json: same, keyed by prompt.
AP22_stage1_prompts_v0.1.txt       AP22 master file (current). Passed on Claude; ChatGPT runs owed.
AP22_P*_v0.1.txt                   AP22 single prompts. ap22_v01.json: same, keyed by prompt.
CURRENT VERSIONS: AP1 v0.3, AP2 v0.2, AP5 v0.2, AP6 v0.2, AP17 v0.3, AP22 v0.1.
