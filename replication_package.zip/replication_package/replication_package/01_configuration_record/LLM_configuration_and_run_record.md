# LLM configuration and run record

Study: *Automating the Judgement Step of Use Case Antipattern Detection: An Evaluation with LLM Judges*. Period covered: 10–16 October 2026 (times are Abu Dhabi time, UTC+4, unless marked UTC).

**About this record.** This is a summary of the working log kept during the study, prepared for publication. It records every LLM run, its configuration and outcome, the pilots and the decisions that shaped the design. Row-level detail (every generated model, every call) is in the run sheets and run logs of the replication package, which this record points to. Omitted from this summary: the early planning notes and draft paper text; account and administrative notes; and a provisional scoring of stage 1 against an LLM-drafted reference that was discarded before the construction key was adopted.

## 1 LLM roles and settings

| Role | Model | Access and settings |
| --- | --- | --- |
| Generator, stage 1 | Claude Opus 5.5; GPT-6 (model picker labels; exact build identifiers not shown by the apps) | Claude app and ChatGPT Plus (desktop web browser); a fresh chat for every prompt. In the pilot, Claude incognito chats and ChatGPT temporary chats with memory off. Sampling settings are not exposed by the apps; the reasoning level selected in the ChatGPT app was not recorded. |
| Generator, stage 2 | `claude-opus-5-5`, `gpt-6-astra` | Provider APIs through a script, default settings; output limits 16,000 (Claude) and 25,000 (ChatGPT) tokens. |
| Judge | `claude-opus-5-5`, `gpt-6-astra`, `gemini-3.1-pro-preview` | Batch APIs (Anthropic Message Batches; OpenAI Batch on `/v1/responses`; Gemini Batch). One user message per call; no system prompt; no temperature, reasoning, thinking or effort setting, so provider defaults apply. Output limits: 16,000 (Claude), 25,000 (ChatGPT, Gemini). |
| Research assistant | Claude Opus 5.5 (`claude-opus-5-5`), in planning conversations separate from all research runs | Drafted generation and evaluation prompts and scripts for the researcher's review; checked pilot outputs; screened the stage 1 corpus; computed scores. The researcher reviewed and approved every prompt and verified every model without LLM help. |

Gemini was never used as a generator, as a control for self-preference.

## 2 Stage 1 corpus generation

### 2.1 Prompt development and pilots (10 October 2026)

Each antipattern has one generation template (shared text plus one slot block per model type). Every template was piloted in pilot-only domains before production; pilot outputs never entered the corpus. Pilot outputs were checked by the assistant in the planning conversation, with the researcher's sign-off.

| Antipattern | Versions piloted | Outcome |
| --- | --- | --- |
| AP1 | v0.2, v0.3 | v0.2 on ChatGPT: the acceptable case (P3) failed, label unclear. v0.3: all five slots passed on Claude; P3 and P4 re-run and passed on ChatGPT. |
| AP2 | v0.1, v0.2 | v0.1 on ChatGPT: P2 and P3 passed; P4A had a wording problem, P4B an unclear label. v0.2: all four slots passed on Claude; the owed ChatGPT P4A re-run passed. |
| AP5 | v0.1, v0.2 | v0.1 (one child) failed on the problem case: the parent came out vague rather than incomplete. v0.2 (one parent, two children) passed on both generators. |
| AP6 | v0.1, v0.2 | The acceptable case and the three problem kinds passed on both generators; a two-actor acceptable variant (P3B) was dropped after two strained outputs. |
| AP17 | v0.1 to v0.3 | Revised to v0.3 during the pilot; all slots passed on both generators. The catalogue was updated so that partial overlap is no longer a problem criterion. |
| AP22 | v0.1, v0.2 | All five slots passed on Claude on v0.1; ChatGPT runs were delayed by replies breaking off on the evening of 10 October and completed afterwards; slot P2 revised to v0.2. |

Pilot closed on 10 October 2026 with passing outputs from both generators for every slot kept. Prompts were then frozen as version 1.0, with the wording changes listed in `CHANGES_v1.0.txt` in the package.

Format rejects in the pilot: a few outputs lacked the required form. Two Claude runs showed that prompts were sometimes cut when pasted into the chat, so these outputs were relabelled "cause unknown, truncation suspected" and no format-reject rate is reported. From then on, every pasted prompt was checked to end with its last template line before sending.

### 2.2 Production design (10–11 October 2026)

- 240 models: 24 sets of 10, one model per production domain (a shared clean set of 10, and AP1 4 sets, AP2 3, AP5 4, AP6 2, AP17 5, AP22 5).
- Generator assignment: 120 models per generator, every set 5 and 5, every domain 12 and 12; balanced matrix followed by 50,000 random margin-preserving swaps (seed 20261010). Problem sub-kinds rotated across generators (AP2: P4A and P4B; AP6: P4A, P4B, P4C). Order of work shuffled within each generator.
- Workflow: one prompt per fresh chat, pasted as text; each reply saved with the copy button into its own file; files checked by script after each sitting (complete reply, markers, template lines, actor and use case counts, relationships, structural triggers) and labels checked against the slot.

### 2.3 Production (11 October 2026)

| | Claude | ChatGPT |
| --- | --- | --- |
| Sittings | 14:06–15:26 and 18:19–19:00 | 19:41–21:54 (two short breaks) |
| Accepted | 120 of 120 | 120 of 120 |
| Extra attempts | 3 models needed a second attempt (CLEAN-P1-D01, AP17-P2A-D04, AP17-P2A-D10) | 3 models needed more attempts (AP17-P2A-D03, AP22-P4A-D05: accepted on the third; AP17-P2A-D09: on the second); 5 rejected replies in all |
| Prompt variants | v1.0 | v1.0c: v1.0 plus one delivery line asking for the reply inside a code block, because the ChatGPT app otherwise lost line breaks when copying. AP17 slot P2A v1.1 (one added naming sentence) for D03 and D09 after repeated rejections on the same ground. |
| File check | All 120 complete and consistent with their run; three empty files refilled from the chat history with the accepted replies | All 120 complete and consistent; a stray closing line in six replies |

The checked corpus copy removes those six stray lines and normalises trailing whitespace; nothing else was changed. Neutral ids M001–M240 were assigned by a seeded shuffle (seed 20261011), and the model files were copied unchanged under those names. Row-level detail: `run_sheet_Claude.csv` and `run_sheet_ChatGPT.csv`.

## 3 Evaluation prompt (11–12 October 2026)

Design decisions by the researcher, 11 October:
- Whole-catalogue judging: each model is judged against all six studied antipatterns in one prompt; the prompt contains only those six.
- Every finding must name the constructs involved; a PROBLEM verdict counts as catching a problem only if the constructs match.
- Scoring is binary per model and antipattern: "no trigger reported" and "trigger reported, ACCEPTABLE" both count as acceptable. Acceptable-trigger reports are used only to explain errors.
- The judge proposes an improvement for each PROBLEM verdict, chosen from those the catalogue lists.

Version 0.1 was drafted by the assistant and revised by the researcher into version 0.2 (improvement lines added). Criteria that only the modeller can answer (among the six, AP1 criterion 3) were left out.

**Chat-window pilot (11–12 October, 12 models, one run each).** Claude 12 of 12 correct; ChatGPT 12 of 12; all planted problems found with the intended criterion by both. The Gemini pilot sitting used Gemini 3.5 Flash-Lite with thinking off (10 of 12 correct). As a small non-reasoning model, its results are not comparable, and the full runs used Gemini's top Pro model through the API instead.

**API trials (12 October, 20 models, one run each, prompt v0.2).** All three judges returned 20 of 20 complete, well-formed replies; on each model's own antipattern, all 6 planted problems were found with matching constructs and no false alarm was raised. Default reasoning effort differed markedly: ChatGPT used 0 to 300 reasoning tokens per call, while Gemini used roughly 500 to 8,000.

**Frozen (12 October, 00:53).** Version 0.2 was frozen unchanged as version 1.0 and sent identically to all judges through their APIs, with three repetitions per judge and batch mode for all.

## 4 Stage 1 judging (12–13 October 2026)

| Judge | Submitted | Batches | Outcome | Tokens (input / output) |
| --- | --- | --- | --- | --- |
| Claude `claude-opus-5-5` | 12 Oct 21:39 | `msgbatch_01Xx6yqQV1CursaBtFHkPmKi` | 720 of 720 complete (end_turn); no errors | 2,459,268 / 551,522 |
| ChatGPT `gpt-6-astra` | 12 Oct 21:55 | First batch rejected before running (enqueued-token limit, nothing run); resubmitted 13 Oct as `batch_6acda210b81881909d9ce2701837fae9` (runs 1–2) and `batch_6acda5c1b5608190bd58f8e9ad05c3ef` (run 3) | 720 of 720 complete | 1,631,451 / 258,439 |
| Gemini `gemini-3.1-pro-preview` | 12 Oct 22:01 | `batches/ud45vwplfocuyr4qct319dafgwpp8a5jll3n`; rerun `batches/ax0yv8jz52yvsxhgsl37t8h9d2tr7ub9lksl` | 699 of 720 at first: 21 requests failed on the provider's side with no reply, and were resent unchanged; 720 of 720 complete | about 1.64 M / 2.17 M (first batch) |

No reply was cut off or malformed. Requests were never changed between submissions. Per-call detail is in each judge's `run_log.csv`.

## 5 Reference and verification (16 October 2026)

- Reference: the construction key, that is, each model's own antipattern labelled by the generation slot it was built for.
- The researcher verified every stage 1 model against its slot without LLM assistance; all labels were confirmed. The verification was not blind to the slot.

## 6 AP5 follow-up run (15–16 October 2026)

- Purpose: find out whether ChatGPT's AP5 misses in stage 1 came from the six-antipattern prompt or from how it reads the AP5 criteria. The stage 1 results stand unchanged whatever this run shows.
- Setup: evaluation prompt v1.0 with only the AP5 entry kept; ChatGPT `gpt-6-astra`, default settings; the 40 AP5 models, 3 runs each, 120 standard calls.
- Result: 120 of 120 complete. 6 of 10 problems judged acceptable in every run (stage 1: 6, 6, 7); no false alarm; verdicts identical across runs. 93 of 120 calls used no reasoning tokens. ChatGPT judged the parent a complete ordinary service because its flow records a result, without checking whether the children are the only kinds of the service. Conclusion: the misses come from how ChatGPT reads the criterion, not from the prompt.

## 7 Stage 2 (16 October 2026)

**Design.** Sizes were taken from the researcher's corpus of 78 real diagrams from another study (median 5.5 use cases, 90% at most 11; median 3 actors). Stage 2 has 24 models of 9–12 use cases and 2–4 actors, 12 per generator, in 12 new domains. Each model carries three planted fragments of different antipatterns: 72 in all, 12 per antipattern (4 near miss, 4 acceptable, 4 problem), reusing the stage 1 slot wording (seed 20261016). Each model also has 2–5 other use cases with no relationships. The generation prompt was drafted by the assistant and approved by the researcher.

**Generation.** The models were generated by script through the APIs at default settings. Two pilot models came first (S2-CL-01, S2-CH-01), then the rest. All 24 were well formed, at exactly the designed sizes, with no rejection or regeneration; the pilot models were kept, since no prompt changed. Per-call detail is in `generation_log.csv`.

**Judging.** Neutral ids N01–N24 were assigned (seed 20261017). Evaluation prompt v1.0 was used unchanged, with the same judges and settings as stage 1: 72 calls per judge, submitted about 16:10. Batches: Claude `msgbatch_01PPdEF2N6nDCBPzY1ui8RRm`, ChatGPT `batch_6ad21427998881908eea92f02799d4f9`, Gemini `batches/dj9z7fflvzkfcxd3mg6dycwcc7xwl88hoz3q`. All 72 replies per judge were complete and well formed, with no reruns. Rule: the researcher did not open judge replies until his verification was complete.

**Verification.** The researcher verified all 72 planted fragments without LLM help and confirmed each as designed, including the names of the planted semantic problem pairs.

**Correction to the key.** The researcher's first verification report listed no accidental semantic triggers. After the aggregate results had been shared, he reported an AP22 problem in S2-CL-03, between Receive Returned Book and Route Returned Copy. He states that he identified it during verification and left it out of his first report by oversight. It is scored as a problem, giving 25 problems.

**Result** (caught of 25 / false alarms, per run):
- Claude: 25/0, 24/0, 24/0.
- ChatGPT: 24/0 in every run.
- Gemini: 25/3, 24/2, 25/3.

By majority of three runs, Claude and ChatGPT each caught 24 of 25 with no false alarm, and Gemini caught 25 of 25 with 2 false alarms. Those were AP6 on the planted acceptable extension in S2-CH-11, and AP22 between Buy Tickets and its extension Report Near Sell-Out in S2-CL-10. The only problem missed by a majority is the AP5 problem in S2-CL-06.
